package gr.aueb.cf.ch17.exercise01;

public interface IRectangle extends IShape, ITwoDimensional {
}
